import UIKit

//var str = "Hello, playground"
//
//var someArray: Array<Decimal> = Array(arrayLiteral: 1, 5, 7)
//
//print(someArray)

print(Float16.pi)
print(Float32.pi)
print(Float64.pi)
print(Float80.pi)
print(Decimal.pi)

var x: Int = 16
var y: Int = 50
var z = x + y
print(z)

//print(Float16.pi)

//func calcAB (_ a:Int,_ b:Int) -> Int{
//    return (a + b)
//}
//
//print(calcAB(5,6))
//
//func addTwoInts(_ a: Int,_ b:Int) ->Int{
//    return (a + b)
//}
//
//var mathFunction: (Int, Int) -> Int = addTwoInts
//
//mathFunction(4,7)
